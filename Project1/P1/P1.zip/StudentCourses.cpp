//============================================================================
// File Name   : StudentCourses.cpp
// Author      : You
// Version     : 1.0
// Copyright   : Your copyright notice (if applicable)
// Description : C++ project 1 for CSCE 113
//============================================================================

// Your code starts here
#include "Student.h"
#include "Courses.h"
#include "StudentCourses.h"

/* StudentCourses::StudentCourses() {} */
 StudentCourses::StudentCourses(Student s, Courses c): student(s), courses(c){} 

double StudentCourses::get_final_score() const{
	/* courses.calc_final_score();
	courses.calc_final_grade(); */
	return courses.get_final_score();
}
string StudentCourses::get_last_name() const{
	return student.get_last_name();
}
string StudentCourses::get_first_name() const{
	return student.get_first_name();
}
void StudentCourses::display() const{
	student.display();
	courses.display();
}
