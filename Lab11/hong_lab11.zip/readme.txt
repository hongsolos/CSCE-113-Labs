//======================================================================
//*  FILE NAME: readme.txt                       |* * * * * |##########|
//*  NAME: Han Hong                              | * * * * *|##########|
//*  Lab 11                                      |* * * * * |##########|
//*  CSCE 113 SECTION 501                        |#####################|
//*  UIN: 824000237                              |#####################|
//======================================================================

INFO: Program to sastify lab 11 requirements. Replacing specified UIN format with XXX-XXX-XXX

Files included:
	* Lab11.cpp
	* data.txt

Comments:
 - None

Questions:
 - None

Difficulties:
 - None

Resources:
 - http://www.cplusplus.com/reference/regex/
   + Items researched: regex


**** An Aggie does not lie, cheat or steal or tolerate those who do. ****