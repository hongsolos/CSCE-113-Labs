//======================================================================
//*  FILE NAME: readme.txt     TTTTTTTTTT   A     M       M UU      UU |
//*  NAME: Han Hong                TT      A A    MM     MM UU      UU |
//*  Pre-lab                       TT     A   A   M M   M M UU      UU |
//*  CSCE 113 SECTION 501          TT    AAAAAAA  M  M M  M UU      UU |
//*  UIN: 824000237                TT   AA     AA M   M   M  UUUUUUUU  |
//======================================================================

INFO: Pre-lab of the final project.

Files included:
	* flight.cpp
	* flight.h
	* sort.cpp
	* sort.h
	* main.cpp

Comments:
 - I test with a vector of objects instead of double.

Questions:
 - None

Difficulties:
 - None

Resources:
 - http://www.algolist.net/Algorithms/Sorting/Bubble_sort
   + Items researched: Bubble sort
 - http://www.algolist.net/Algorithms/Sorting/Selection_sort
   + Items researched: Selection sort
 - http://www.cplusplus.com/forum/general/115429/
   + Items researched: Remove a character from a string.


**** An Aggie does not lie, cheat or steal or tolerate those who do. ****